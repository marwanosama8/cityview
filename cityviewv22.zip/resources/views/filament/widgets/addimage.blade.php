<x-filament::widget>
    <x-filament::card>
        <a class="pl-4" href="{{ url('admin/galleries/create') }}">Add new photo for gallery</a>
    </x-filament::card>
</x-filament::widget>
