  <!-- start NavBar -->
  <nav id="Nav"  class="navbar navbar-expand-lg fixed-top Nav">
    <div class="container">
      <a class="navbar-brand Logo-nav" href="<?php echo e(route('index')); ?>">
        <img src="<?php echo e(asset('assets/images/logo-City-without-Bg.png')); ?>" height="70px" alt="">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon">
          <i class="fa-solid fa-bars"></i>
        </span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link lnk" href="<?php echo e(route('index')); ?>">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link lnk2" href="<?php echo e(route('facilities')); ?>">Facilities</a>
          </li>
          <li class="nav-item">
            <a class="nav-link lnk3" href="<?php echo e(route('rooms')); ?>">Rooms</a>
          </li>
          <li class="nav-item">
            <a class="nav-link lnk4" href="<?php echo e(route('gallery')); ?>">Gallery</a>
          </li>
          <li class="nav-item">
            <a class="nav-link lnk4" href="<?php echo e(route('contact.us')); ?>">Contact-us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link lnk5" href="<?php echo e(route('book')); ?>">Book</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
<!-- end NavBar -->
<?php /**PATH /home/marwan/Sites/cityviewv2/resources/views/layouts/header.blade.php ENDPATH**/ ?>