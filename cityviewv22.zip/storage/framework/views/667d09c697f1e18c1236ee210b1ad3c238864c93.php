<svg class="w-5 h-5 filament-icon-button-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
  <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/>
</svg><?php /**PATH /home/marwan/Sites/cityviewv2/storage/framework/views/3fd9b0edabfa9e68ec392dfd90fd1244292e2c65.blade.php ENDPATH**/ ?>