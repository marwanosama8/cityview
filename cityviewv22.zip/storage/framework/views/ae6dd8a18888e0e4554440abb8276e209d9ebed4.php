      <!-- icon fontawesome -->
      <link rel="stylesheet" href="./css/all.min.css" />
      <!-- bootstrab -->
      <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
        crossorigin="anonymous"
      />

      <!-- google font -->
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;700&family=Merriweather:wght@300&family=Montagu+Slab:opsz@16..144&family=Montserrat:wght@300;500&display=swap" rel="stylesheet">

      <!-- google font -->
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;700&family=Merriweather:wght@300;400;700&family=Montserrat:wght@300;500&display=swap" rel="stylesheet">

      <!-- Link Swiper's CSS -->
      <link
        rel="stylesheet"
        href="https://unpkg.com/swiper/swiper-bundle.min.css"
      />

      <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>" />
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>" />

      <!-- my css file -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />
<?php /**PATH /home/marwan/Sites/cityviewv2/resources/views/layouts/links.blade.php ENDPATH**/ ?>